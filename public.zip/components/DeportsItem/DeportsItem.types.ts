export type DeportsProps = {
    items: {
        title: string,
        img: string,
        description: string
    }
}