export type BookingProps = {
    id: number,
    field: string
}