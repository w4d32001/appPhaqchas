export type ImageDeportProps = {
    image: string;
    title: string;
}