"use client";
import Link from "next/link";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Input from "@/components/Input/Input";

export default function Page() {
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [dni, setDni] = useState("");
  const [name, setName] = useState("");
  const [surname, setSurname] = useState("");
  const [address, setAddress] = useState("");
  const [birthday, setBirthday] = useState("");
  const router = useRouter();
  const [errors, setErrors] = useState({
    email: "",
    password: "",
    phone: "",
    dni: "",
    name: "",
    surname: "",
    address: "",
    birthday: "",
    general: "",
  });

  const validateInputs = (): boolean => {
    const newErrors = {
      email: "",
      password: "",
      phone: "",
      dni: "",
      name: "",
      surname: "",
      address: "",
      birthday: "",
      general: "",
    };

    if (!password.trim()) {
      newErrors.password = "La contraseña es obligatoria.";
    } else if (password.length < 6) {
      newErrors.password = "La contraseña debe tener al menos 6 caracteres.";
    }

    if (!phone.trim()) {
      newErrors.phone = "El celular es obligatorio.";
    } else if (phone.length < 9) {
      newErrors.phone = "El celular debe tener al menos 9 caracteres.";
    }

    if (dni.trim() && dni.length < 8) {
      newErrors.dni =
        "El DNI debe tener al menos 8 caracteres si se proporciona.";
    }

    if (!name.trim()) {
      newErrors.name = "El nombre es obligatorio.";
    }

    if (!surname.trim()) {
      newErrors.surname = "El apellido es obligatorio.";
    }

    setErrors(newErrors);
    return !Object.values(newErrors).some((error) => error !== "");
  };

  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!validateInputs()) return;

    try {
      const response = await fetch("http://127.0.0.1:8000/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ password, phone, dni, name, surname }),
      });

      const data = await response.json();
      if (response.ok) {
        const loginResponse = await fetch(
          "http://127.0.0.1:8000/api/auth/login",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ dni, password }),
          }
        );

        if (!loginResponse.ok) {
          const errorData = await loginResponse.json();
          setErrors((prev) => ({
            ...prev,
            general:
              errorData.message || "Error al iniciar sesión automáticamente",
          }));
          return;
        }

        const loginData = await loginResponse.json();
        localStorage.setItem("token", loginData.access_token);

        try {
          const userDataResponse = await fetch(
            "http://127.0.0.1:8000/api/auth/me",
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${data.access_token}`,
              },
            }
          );

          if (!userDataResponse.ok) {
            const errorText = await userDataResponse.text();
            console.error("Error detallado:", errorText);
            throw new Error("Error al obtener los datos del usuario");
          }
          const userData = await userDataResponse.json();
          console.log(userData);

          localStorage.setItem("user", JSON.stringify(userData));
          toast.success("¡Bienvenido, usuario!");
          router.push("/");
        } catch (error: unknown) {
          if (error instanceof Error) {
            console.error(
              "Error al obtener los datos del usuario:",
              error.message
            );
            alert(`Error: ${error.message}`);
          } else {
            console.error("Error desconocido:", error);
            alert("Ocurrió un error inesperado.");
          }
        }
      } else {
        if (data.errors) {
          setErrors((prev) => ({
            ...prev,
            ...data.errors,
          }));
          console.log(data);
        } else {
          setErrors((prev) => ({
            ...prev,
            general: data.message || "Error en el registro.",
          }));
          console.log(data);
        }
      }
    } catch (error: unknown) {
      if (error instanceof Error) {
        setErrors((prev) => ({
          ...prev,
          general: `Error: ${error.message}`,
        }));
      }
    }
  };
  return (
    <div className="bg-custom-gradient h-auto overflow-y-hidden">
      <div className=" grid grid-cols-1 lg:grid-cols-3 p-2">
        <div className="text-white min-h-screen w-full px-2 py-4 gap-2 flex flex-col items-center col-span-1 overflow-y-auto">
          <h2 className="uppercase text-3xl">Phaqchas</h2>
          <span className="text-center font-sans text-sm">
            Regístrate para acceder a promociones y más noticias.
          </span>
          <div className="w-full flex flex-col gap-y-10">
            <form action="" onSubmit={handleRegister}>
              <div className="flex flex-col gap-2">
                <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="">
                    <Input
                      type="text"
                      name="name"
                      placeholder="Juan"
                      label="Nombre"
                      value={name}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        setName(e.target.value)
                      }
                    />
                    {errors.name && (
                      <span className="text-red-600 text-sm">
                        {errors.name}
                      </span>
                    )}
                  </div>
                  <div className="">
                    <Input
                      type="text"
                      name="surname"
                      placeholder="Perez"
                      label="Apellido"
                      value={surname}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        setSurname(e.target.value)
                      }
                    />
                    {errors.surname && (
                      <span className="text-red-600 text-sm">
                        {errors.surname}
                      </span>
                    )}
                  </div>
                </div>
                <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <Input
                      type="password"
                      name="password"
                      placeholder="*********"
                      label="Contraseña"
                      value={password}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        setPassword(e.target.value)
                      }
                    />
                    {errors.password && (
                      <span className="text-red-600 text-sm">
                        {errors.password}
                      </span>
                    )}
                  </div>
                  <div>
                    <Input
                      type="text"
                      name="address"
                      placeholder="calle falsa 123"
                      label="Dirección"
                      value={address}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        setAddress(e.target.value)
                      }
                    />
                    {errors.address && (
                      <span className="text-red-600 text-sm">
                        {errors.address}
                      </span>
                    )}
                  </div>
                </div>

                <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="">
                    <Input
                      type="text"
                      name="phone"
                      placeholder="987564123"
                      label="Celular"
                      value={phone}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        setPhone(e.target.value)
                      }
                    />
                    {errors.phone && (
                      <span className="text-red-600 text-sm">
                        {errors.phone}
                      </span>
                    )}
                  </div>
                  <div className="">
                    <Input
                      type="text"
                      name="dni"
                      placeholder="85632147"
                      label="DNI"
                      value={dni}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        setDni(e.target.value)
                      }
                    />
                    {errors.dni && (
                      <span className="text-red-600 text-sm">{errors.dni}</span>
                    )}
                  </div>
                </div>
                <Input
                  type="date"
                  name="birthday"
                  placeholder="987564123"
                  label="Fecha de nacimiento"
                  value={birthday}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setBirthday(e.target.value)
                  }
                />
                {errors.birthday && (
                  <span className="text-red-600 text-sm">{errors.birthday}</span>
                )}

                <button className="bg-[#162D3A] text-white py-3 rounded-xl hover:bg-[#162D3A]/60 transition-colors mt-4">
                  Registrate
                </button>
              </div>
            </form>
            <div className="flex flex-col gap-4 w-full">
              <span className="text-center text-xl flex items-center px-8">
                <hr className="w-1/3" /> <span className="w-1/3">o</span>{" "}
                <hr className="w-1/3" />
              </span>
              <span className="text-center">
                Ya estas registrado?{" "}
                <Link href="../auth/login" className="text-blue-600">
                  Inicia sesión
                </Link>
              </span>
            </div>
          </div>
        </div>
        <div className="hidden h-auto col-span-2 lg:flex  items-center">
          <img
            src="/assets/voley1.jpg"
            alt=""
            className="h-[calc(100vh-2px)] w-full object-cover rounded-lg shadow-xl"
          />
        </div>
      </div>
      <ToastContainer />
    </div>
  );
}
